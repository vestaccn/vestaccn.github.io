function open_card() {
  document.getElementById('outside').className = 'open-card';
}

function close_card() {
  document.getElementById('outside').className = '';
}